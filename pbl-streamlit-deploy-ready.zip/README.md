# AI Health Assistant

Streamlit app for disease food guidance, BMI tracking, diet planning, and symptom prediction.

## Run locally

```powershell
streamlit run Pbl.py
```

## Streamlit Cloud

- Main file path: `Pbl.py`
- Optional secret: `MONGO_URI`

If `MONGO_URI` is not configured, the app uses local JSON storage for login and BMI history.
